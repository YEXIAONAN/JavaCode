package org.code.general;

import java.time.LocalDateTime;

public class ShowLocalDateTime {
    public static void main(String[] args) {
        LocalDateTime LDateTime = LocalDateTime.now(); // 创建获取对象
        System.out.println(LDateTime);
    }
}
