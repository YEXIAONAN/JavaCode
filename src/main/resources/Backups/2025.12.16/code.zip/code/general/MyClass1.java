package org.code.general;

public class MyClass1 {
    static void myMethod(String fname){
        System.out.println(fname + " Refsnes");
    }

    public static void main(String[] args) {
        myMethod("MyGay");
        myMethod("LaoMuMu");
        myMethod("Gay!");
    }
}
