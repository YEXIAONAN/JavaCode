package org.code.general;

public class IntegerToString {
    public static void main(String[] args) {
        Integer myInt =10;

        String myString = myInt.toString();

        System.out.println(myString.length());
    }
}
