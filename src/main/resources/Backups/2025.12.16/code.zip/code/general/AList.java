package org.code.general;

import java.util.ArrayList;

public class AList {
    public static void main(String[] args) {
        ArrayList<String> cars = new ArrayList<String>(); // 创建一个 ArrayList 对象
    }
}
