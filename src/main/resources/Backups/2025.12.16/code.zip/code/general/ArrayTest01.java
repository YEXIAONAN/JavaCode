package org.code.general;

public class ArrayTest01 {
    public static void main(String[] args) {
        String[] cars = {"Gay","MuGay","MuG","MuMu"};
        cars[0] = "GayP";
        System.out.println(cars[0]);
    }
}
