package org.code.general;

public class ClassTask1 {
    public static void main(String[] args) {
        System.out.println("书名\t作者\t价格\t销量\n三国\t罗贯中\t120\t1000");
        System.out.println("\\t");
    }
}
