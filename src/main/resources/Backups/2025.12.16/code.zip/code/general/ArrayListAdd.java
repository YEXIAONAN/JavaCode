package org.code.general;

import java.util.ArrayList;

public class ArrayListAdd {
    public static void main(String[] args) {
        ArrayList<String> cars = new ArrayList<String>();

        cars.add("MuGay");
        cars.add("XiaoBa");
        cars.add("High");
        cars.add("SmallGay");
        System.out.println(cars);
    }
}
