package org.code.general;

public class ForEach {
    public static void main(String[] args) {
        String[] cas = {"MuGay","LaoMuGay","YoungMuGay","SiMuGay"};
        for (String i : cas){
            System.out.println(i);
        }
    }
}
