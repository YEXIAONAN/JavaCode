package org.code.general;

public class NestedIf {
    public static void main(String[] args) {

    }
}
