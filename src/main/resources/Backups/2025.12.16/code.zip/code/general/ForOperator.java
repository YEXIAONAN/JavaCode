package org.code.general;

public class ForOperator {
    public static void main(String[] args) {
        for (int i = 0; i < 10;i++  ){
            System.out.println(i);
        }

        for (int i = 0; i < 11; i = i + 2){
            System.out.println(i);
        }
    }
}
