package org.code.general;

public class MyClass {
    static void myMethod(){
        System.out.println("I am MuGay!");
    }

    public static void main(String[] args) {
        myMethod();
    }
}
