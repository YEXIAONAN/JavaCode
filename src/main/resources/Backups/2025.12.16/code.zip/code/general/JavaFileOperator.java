package org.code.general;

import java.io.File;

public class JavaFileOperator {
  public static void main(String[] args) {
    File myObj = new File("filename.txt");
  }
}
