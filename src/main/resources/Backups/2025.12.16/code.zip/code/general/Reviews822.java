package org.code.general;

public class Reviews822 {


    public static void main(String[] args) {

//        // 创建输入对象，获取User输入
//        Scanner sc = new Scanner(System.in);
//
//        int Bank_your_money = 0;
//        int Back_all_money = 10000;
//
//        System.out.println("---- Bank ----");
//        System.out.println("Now you have money is " + Bank_your_money);
//        System.out.println("Please enter you need insert money");
//        int Your_input_money = sc.nextInt();
//
//        // 对用户输入的钱进行存储
//
//        int New_Bank_your_money = Bank_your_money + Your_input_money;
//
//        System.out.println("---- Bank ----");
//        System.out.println("Now you have " + New_Bank_your_money + "Money!");
//
//        System.out.println("Maby you need output money?");

        for (int i = 0; i < 100; i++) {
            System.out.println("小奶狗 " + i);
            System.out.println();

        }
    }
}
