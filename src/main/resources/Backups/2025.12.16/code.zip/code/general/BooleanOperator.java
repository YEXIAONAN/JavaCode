package org.code.general;

public class BooleanOperator {
    public static void main(String[] args) {
        boolean t = true;
        boolean f = false;
        System.out.println(t);
        System.out.println(f);
    }
}
