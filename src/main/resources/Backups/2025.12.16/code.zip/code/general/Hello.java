package org.code.general;


public class Hello {
	public static void main(String[] args) {
		System.out.println("我是小猫猫");
	}
}


class Dog {
	public static void main(String[] args) {
		System.out.println("我是小狗狗");
	}
}

class Mugun {
	public static void main(String[] args) {
		System.out.println("我是木棍");
	}

}