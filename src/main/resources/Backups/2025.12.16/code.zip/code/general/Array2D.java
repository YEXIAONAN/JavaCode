package org.code.general;

public class Array2D {
    public static void main(String[] args) {
        int[][] MyNums = { {1, 2, 3, 4}, {5, 6, 7} };
        int x = MyNums[1][2];
        System.out.println(x);
    }
}
