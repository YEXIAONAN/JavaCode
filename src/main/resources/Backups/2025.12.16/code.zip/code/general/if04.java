package org.code.general;

public class if04 {
    public static void main(String[] args) {
        //
    }
}
