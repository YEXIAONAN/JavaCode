package org.code.general;

public class AssignOperator {
    public static void main(String[] args) {
        int n1 = 10;
        n1 += 4;//等价于 n1 = n1 + 4
        System.out.println(n1);
    }
}
