package org.code.general;

public class AutoConvert {
    public static void main(String[] args) {
        // 演示自动转换
        int num = 'a'; // char > int
        System.out.println(num);
        double d1 = 80;//int > double
        System.out.println(d1);
    }
}
