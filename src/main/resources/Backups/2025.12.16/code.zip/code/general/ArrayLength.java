package org.code.general;

public class ArrayLength {
    public static void main(String[] args) {
        String[] cars = {"Gay","MuGay","MuG","MuMu"};
        System.out.println(cars.length);
    }
}
