package org.code.general;

public class Boolean01 {
    public static void main(String[] args) {
        // 演示判断成绩是否通过案例
        // 定义一个布尔变量
        boolean isPass = false;
        if (isPass == true){
            System.out.println("Tests Accept!");
        }else {
            System.out.println("Tests Fail!");
        }
    }
}
