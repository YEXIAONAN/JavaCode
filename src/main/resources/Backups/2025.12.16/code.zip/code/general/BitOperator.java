package org.code.general;

public class BitOperator {
    public static void main(String[] args) {
        // 位运算
        System.out.println(2&3);
    }
}
