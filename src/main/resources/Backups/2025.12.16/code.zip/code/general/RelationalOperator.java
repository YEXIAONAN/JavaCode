package org.code.general;

public class RelationalOperator {
    public static void main(String[] args) {
        int xiaoming = 9;
        int xiaohong = 8;

        System.out.println(xiaoming>xiaohong);
        System.out.println(xiaoming>=xiaohong);
        System.out.println(xiaoming<=xiaohong);
        System.out.println(xiaoming<xiaohong);
        System.out.println(xiaoming==xiaohong);
        System.out.println(xiaoming!=xiaohong);
        boolean flag = xiaoming > xiaohong;
    }
}
