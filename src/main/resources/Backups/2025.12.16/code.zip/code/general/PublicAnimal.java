package org.code.general;

public class PublicAnimal{

}
