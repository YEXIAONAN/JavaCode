package org.code.develop.homework;

public class hk02 {
    public static void main(String[] args) {
        char a1 = '\n';
        char a2 = '\t';
        char a3 = '\r';
        char a4 = '\\';
        char a5 = '1';
        char a6 = '2';
        char a7 = '3';
        System.out.println(a1);
        System.out.println(a2);
        System.out.println(a3);
        System.out.println(a4);
        System.out.println(a5);
        System.out.println(a6);
        System.out.println(a7);
    }
}
