package org.code.develop.threading;

public class MyThread1 extends Thread {
  public void run() {
    System.out.println("This code is running in a thread");
  }
}
