package org.code.develop.Interface;

interface Animal2 {
    // 接口方法
    public void animalSound();

    // 接口方法
    public void run();
}
