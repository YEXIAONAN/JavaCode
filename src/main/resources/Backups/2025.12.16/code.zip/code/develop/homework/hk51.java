package org.code.develop.homework;

public class hk51 {
    public static void main(String[] args) {
        // 分支控制 if-else
        int x = 7;
        int y = 5;
        if (x >= 5){
            if (y >= 5){
                System.out.println(x + y);
            }
                System.out.println("我是木棍");
        }else {
            System.out.println("x is " + x);
        }
    }
}
