package org.code.develop.test;

public class MyClass {
    static void myMethod(){
        System.out.println("Hello,World!");
    }

    public static void main(String[] args) {
        myMethod();
    }

    // 输出"Hello,World!"
}
