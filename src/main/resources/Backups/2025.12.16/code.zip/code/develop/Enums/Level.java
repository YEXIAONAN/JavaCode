package org.code.develop.Enums;

enum Level {
    Low,
    Medium,
    High
}
