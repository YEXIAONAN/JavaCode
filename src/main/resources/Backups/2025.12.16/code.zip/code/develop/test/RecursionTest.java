package org.code.develop.test;

public class RecursionTest {
    public static void main(String[] args) {
        int sum = 10;
        // 求sum的求和
        System.out.println(sum);




    }
}
