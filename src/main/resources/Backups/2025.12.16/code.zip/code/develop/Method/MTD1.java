package org.code.develop.Method;

public class MTD1 {
    class Person {
        public String name;
        public int age;
    }

    Person ming = new Person();

}
