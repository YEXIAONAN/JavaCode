package org.code.develop.threading;

public class MyThread2 implements Runnable {
  public void run() {
    System.out.println("This code is running in a thread");
  }
}
