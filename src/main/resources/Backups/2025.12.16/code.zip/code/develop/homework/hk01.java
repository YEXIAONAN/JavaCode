package org.code.develop.homework;

public class hk01 {
    public static void main(String[] args) {
        int n1;
        n1 = 13;

        int n2;
        n2 = 17;

        int n3;
        n3 = n1 + n2; //30
        System.out.println("n3 = " + n3);

        int n4 = 38;
        int n5 = n4 - n3;// 38 - 30 =8
        System.out.println("n5 = " + n5);
    }
}
