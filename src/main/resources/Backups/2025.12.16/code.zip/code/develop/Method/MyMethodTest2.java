package org.code.develop.Method;

public class MyMethodTest2 {
    // 定义一个方法（print）
    static void print (String output){
        // 指定这个方法中的用途
        System.out.println(output);
    }

    // 编写Main入口
    public static void main(String[] args) {
        print("我是输出语句");
    }
}
