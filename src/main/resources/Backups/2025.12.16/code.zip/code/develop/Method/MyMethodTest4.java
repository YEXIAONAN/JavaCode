package org.code.develop.Method;

public class MyMethodTest4 {
    static int Sum (int x,int y){
        return  x + y;
    }

    public static void main(String[] args) {
        int z = Sum(7,8);

        System.out.println(z);
    }

}
