package org.code.Swing;

import javax.swing.*;

public class SwingLoginExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Login Example");

        frame.setSize(350,200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    }
}
