package org.code.jdbc;

public class MyTest {
    static final String MySQL_URL = "jdbc:mysql://172.16.7.70/root";
    static final String MySQL_User = "root";
    static final String MySQL_Password = "123456";
    public static void main(String[] args) {

    }
}
