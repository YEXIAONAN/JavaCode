package org.code.review;

public class ReassignVariable {
    public static void main(String[] args) {
        int x = 100;
        System.out.println(x);
        // 重新赋值变量
        x = 200;
        System.out.println(x);
    }
}
