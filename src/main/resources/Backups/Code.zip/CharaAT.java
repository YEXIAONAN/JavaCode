package org.yexiaonan;

public class CharaAT {
    public static void main(String[] args) {
        String s = "MuMu.com";
        char result = s.charAt(6);
        System.out.println(result);
    }
}
