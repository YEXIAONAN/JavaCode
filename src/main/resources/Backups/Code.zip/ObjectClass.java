package org.yexiaonan;

public interface ObjectClass {
    // 方法重写
    void makeSound();
}
