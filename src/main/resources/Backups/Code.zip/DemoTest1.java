package org.yexiaonan;

public class DemoTest1 {
    public static void main(String[] args) {
        System.out.println("HelloWorld!");
        System.out.println("I am a person");

        int Age = 12;
        String Name = "XiaoNan";

        System.out.println("Print" +  Age  +  Name);
    }
}
