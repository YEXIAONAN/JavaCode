package org.yexiaonan;

public class NumChange {
    public static void main(String[] args) {
        byte a1 = 10;
        byte a2 = 20;
        byte result = (byte)(a1 + a2);
        System.out.println(result);
    }



}
