package org.yexiaonan;

public class VideoInfo {
    public static void main(String[] args) {
        String VideoName = "送初恋回家";
        String VideoMainPeople = "刘鑫，张雨提，高媛";
        int VideoYearTime = 2020;
        double VideoScore = 9.0;

        System.out.println(VideoName);
        System.out.println(VideoMainPeople);
        System.out.println(VideoYearTime);
        System.out.println(VideoScore);
    }
}
