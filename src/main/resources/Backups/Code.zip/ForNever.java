package org.yexiaonan;

public class ForNever {
    public static void main(String[] args) {
        for (;;){
            System.out.println("木棍下面有点臭");
        }
    }
}
