package org.yexiaonan;

import java.util.Date;

public class NowDate {
    public static void main(String[] args) {
        Date time = new Date();
        System.out.println(time);
    }
}
