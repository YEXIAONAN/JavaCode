package org.yexiaonan;

public class Demo2 {
    public static void main(String[] args) {
        // 判断运算符
        // 1.==判断左右两边是否相等
        int a = 10;
        int b = 10;
        int c = 20;

        // 当a等于b输出true代表等于
        System.out.println(a == b);

        // 当c等于b输出false代表不等于
        System.out.println(c == a);


        System.out.println(a!=b);
        System.out.println(a!=c);
    }


}
