package org.yexiaonan;

public class Exercises2 {
    public static void main(String[] args) {
        // The no code ：）
    }
}
