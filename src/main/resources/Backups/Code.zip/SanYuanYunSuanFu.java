package org.yexiaonan;

public class SanYuanYunSuanFu {
    public static void main(String[] args) {
        int number1 = 10;
        int number2 = 20;

        int number = number1 > number2 ? number1 : number2;
        System.out.println(number);

        System.out.println(number1 > number2 ? number1 : number2);
    }
}
