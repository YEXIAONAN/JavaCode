package org.yexiaonan;

public class iFChose {
    public static void main(String[] args) {
       boolean  wine = false;
       if (wine){
           System.out.println("1");
       }else {
           System.out.println("2");
       }
    }
}
