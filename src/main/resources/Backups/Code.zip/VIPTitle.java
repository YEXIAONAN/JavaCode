package org.yexiaonan;

public class VIPTitle {
    public static void main(String[] args) {
        int VipLevel5 = 5;
        int VipLevel4 = 4;
        int VipLevel3 = 3;
        int VipLevel2 = 2;
        int VipLevel1 = 1;

        // Max VIP Level Is 5

    }
}
