package org.yexiaonan;

public class StringAddCharacter {
    public static void main(String[] args) {
        String data = "MuMu";
        String NanNan = "NanNan";

        "我爱撩骚".concat(data);
        System.out.println(data);
    }
}
