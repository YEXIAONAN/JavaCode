package org.yexiaonan;

public class CHA {
    public static void main(String[] args) {
        Character ch = new Character('a');

        System.out.println(ch);
    }
}
