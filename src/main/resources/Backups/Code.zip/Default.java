package org.yexiaonan;

public class Default {
    private boolean MyFlag;
    static final double weeks = 9.9;
    protected static final int Sum = 44;
    public static void main(String[] args) {
        System.out.println(weeks);
        System.out.println(Sum);
    }
}
