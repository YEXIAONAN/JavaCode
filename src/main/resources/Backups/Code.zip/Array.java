package org.yexiaonan;

// never useing
// import java.util.Arrays;

public class Array {
    public static void main(String[] args) {
        int [] num = {11,11};
        // 需求一：存储五个学生的年龄
            int[] arr1 = new int[]{11,22,33,44};

            int[] arr2 = {11,22,33,44};
        // 需求二：存储四个学生的姓名
            String[] arr3 = new String[]{"mugun1","mugun2","mugun3","mugun4"};

            String[] arr4 = {"mugun1","mugun2","mugun3","mugun4"};
        // 需求三：存储四个学生的身高
            double[] arr5 = new double[]{178.7, 168.5, 177.6, 165.8};

            double[] arr6 = {178.7, 168.5, 177.6, 165.8};

            int[] arr7 = {11,22,33,44};



    }
}
