package org.yexiaonan;

public class ReviewCode {
    public static void main(String[] args) {
        // 将1~100反方向输出
        for (int i = 100; i >= 1; i--){
            System.out.println(i);
        }

        //
    }
}
