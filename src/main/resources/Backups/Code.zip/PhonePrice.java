package org.yexiaonan;

public class PhonePrice {
    // 输出手机价格
    public static double MyPhonePrice = 5299.00;

    // 手机名称
    public static String PhoneName = "HUAWEI Mate 30E Pro 5G";

    public static void main(String[] args) {
        System.out.println("这部手机的价格为: " + MyPhonePrice + " 这部手机的名字是: " + PhoneName);
    }
}
