package org.yexiaonan;

public class ArrayAdd {
    public static void main(String[] args) {
        // 定义一个动态的数组对象
        String[] one = new String[50];

        // 往数组里面插入数据
        one[0] = "MuMu";
        one[1] = "MuMu2";

        // 获取数据
        System.out.println(one[0]);
        System.out.println(one[1]);
    }
}
