package org.yexiaonan;

public class Animal {


    // 构造方法
//    public Animal(){
//        System.out.println("无效构造方法");
//        Name = "动物";
//        Age = 0;
//
//    }

    public static void main(String[] args) {
        String Name = "";
        int Age;
        System.out.println(Name);
    }


}
