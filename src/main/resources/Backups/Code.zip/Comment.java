package org.yexiaonan;

public class Comment {
    public static void main(String[] args) {
        System.out.println("注释类型");

        // 单行注释

        /*
        多行注释
         */

        /**
         @ Author 指定Java程序的作者
         @ Version 指定源文件的版本
         */
    }
}
