package org.yexiaonan;

public class MethodFor3 {
    public static void main(String[] args) {
        One();
    }
    public static void One(){
        int sum = 10;
        int sum2 =20;

        int result = sum + sum2;
        System.out.println(result);
    }
}
