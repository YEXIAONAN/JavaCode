package org.yexiaonan;

public class NumAdd {
    public static void main(String[] args) {
        int a = 10;
        a++;
        System.out.println(a);

        int b = 10;
        b--;
        System.out.println(b);
    }
}
