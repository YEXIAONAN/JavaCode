package org.yexiaonan;

public class SBF {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("NanBuLiBlog:");
        sb.append("blog");
        sb.append(".nanbuli");
        sb.append(".top");
        System.out.println(sb);
    }
}
