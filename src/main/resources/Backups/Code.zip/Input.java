package org.yexiaonan;

import java.util.Scanner;

public class Input {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Please Enter");
        String data = sc.next();
        int data1 = sc.nextInt();
        System.out.println("木木老师输入了" + data);
        System.out.println("木木老师输入了" + data1);
    }
}
