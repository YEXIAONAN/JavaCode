package org.yexiaonan;

public class ForHelloWorld {
    public static void main(String[] args) {
        // 打印1~5
        for (int i = 1;i <= 5; i++){
            System.out.println("Hello World");
        }

        // 打印5~1
        for (int i2 = 5 ; i2 >= 1 ; i2--){
            System.out.println(i2);
        }
    }
}
