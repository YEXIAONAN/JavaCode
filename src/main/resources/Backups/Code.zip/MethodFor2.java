package org.yexiaonan;

public class MethodFor2 {
    public static void main(String[] args) {
        GirlFriend();
    }

    public static void GirlFriend(){
        System.out.println("小楠");
        System.out.println("楠楠");
        System.out.println("18岁");
    }
}
