package org.yexiaonan;

public class SB {
    public static void main(String[] args) {
        StringBuilder sib = new StringBuilder();
        sib.append('+');

    }
}
