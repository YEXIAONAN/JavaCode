package org.yexiaonan;

import java.util.Scanner;

public class TwoIntForSix {
    public static void main(String[] args) {
        System.out.println("Please Enter frist number：");
        Scanner s1 = new Scanner(System.in);
        int Input1 = s1.nextInt();

        System.out.println("Please Enter two number：");
        int Input2 = s1.nextInt();

        System.out.println(Input1);
        System.out.println(Input2);


    }
}
