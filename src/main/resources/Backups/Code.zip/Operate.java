package org.yexiaonan;

public class Operate {
    public static void main(String[] args) {
        // 应用场景
        // 可以用取模来判断A是否可以被B整除
        int A = 10;
        int B = 20;
        System.out.println(A % B);
//        System.out.println(3+2);
//
//        System.out.println(3-1);
//
//        System.out.println(7*9);
//
//        System.out.println(9/7);
//
//        System.out.println(10.7/100);
//
//        System.out.println(1.1+1.01);

    }
}
