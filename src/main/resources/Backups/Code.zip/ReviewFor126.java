package org.yexiaonan;

import java.util.Arrays;

public class ReviewFor126 {
    public static void main(String[] args) {
        // set a Array for number
        int [] arr = {11,223,344,4545};
        System.out.println(Arrays.toString(arr));

        //
    }

}
