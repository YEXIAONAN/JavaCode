package org.yexiaonan;

public class StaringPrivileges {
    private static final String ERROR = "错误";
    public static void main(String[] args) {
        System.out.println(ERROR);
    }
}

