package org.yexiaonan;

public class MethodFor1 {
    public static void main(String[] args) {
        // 调用方法
        PlayGame();
    }
    // 定义方法
    public static void PlayGame(){
        System.out.println("Test");
    }

}
