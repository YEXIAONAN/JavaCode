package org.yexiaonan;

public class NeverCantStop {
    public static void main(String[] args) {
        for (;;){
            System.out.println("MuMu老师");
        }

    }
}
