package org.yexiaonan;

import java.util.Arrays;

public class ObjectAI {
    // 这是一个封装好的(int)方法，运行项目内调用。
    // 测试封装方法B
    int int_Sum;
    int[] int_Sum_Array;

    public void IprintO (){
        System.out.println("int" +  int_Sum);
        System.out.println("int_array" + Arrays.toString(int_Sum_Array));
    }
}
