package org.yexiaonan;

//姓名：奶龙
//年龄：18
//性别：男
//身高：181.7
//是否单身：是

public class TeacherInfo {
    public static void main(String[] args) {
        String TeacherName = "奶龙";
        int TeacherAge = 18;
        char TeacherSex = '男';
        double TeacherTall = 181.7;
        boolean Teacher = true;

        System.out.println("老师简介，姓名：" + TeacherName + " 年龄：" + TeacherAge + " 性别：" + TeacherSex + " 身高" + TeacherTall + " 是否单身：" + Teacher );
    }
}
