package org.yexiaonan;

public class Exercises1 {
    public static void main(String[] args) {
        String name = "康师傅";
        String sex = "男";
        String home = "背景程序员聚集地：回龙观";

        System.out.println("姓名：" + name);
        System.out.println("");
        System.out.println("性别" + sex);
        System.out.println("家庭住址：" + home);

    }
}
